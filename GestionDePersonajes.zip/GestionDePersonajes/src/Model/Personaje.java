
package Model;

import java.io.Serializable;

public class Personaje implements Comparable<Personaje>, Serializable, CSVSerializable {
    private int id;
    private String nombre;
    private Clase clase;
    private int nivel;

    public Personaje(int id, String nombre, Clase clase, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    public int getNivel() {
        return nivel;
    } 

    public Clase getClase() {
        return clase;
    }
    
    
    @Override
    public String toString() {
        return "Personaje{" + "id= " + id + ", nombre= " + nombre + ", clase= " + clase + ", nivel= " + nivel + '}';
    }

    @Override
    public int compareTo(Personaje otroNombre) {
        return this.nombre.compareTo(otroNombre.nombre);
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (o instanceof Personaje l) {
            return Integer.compare(id, l.id) == 0;
        }
        if (o instanceof Clase c) {
            return clase.equals(c);
        }
        return false;
    }

    public static Personaje fromCSV(String csv) {
        String[] values = csv.split(",");

        if (values.length != 4) throw new IllegalArgumentException("Formato CSV incorrecto");

        try {
            int id = Integer.parseInt(values[0].trim());
            String nombre = values[1].trim();
            Clase clase = Clase.valueOf(values[2].trim().toUpperCase());
            int nivel = Integer.parseInt(values[3].trim());

            return new Personaje(id, nombre, clase, nivel);

        } catch (Exception ex) {
            throw new IllegalArgumentException("Error al parsear CSV: " + ex.getMessage());
        }

    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + clase.toString() + "," + nivel ;
    }
    
    
}
