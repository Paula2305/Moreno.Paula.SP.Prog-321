
package Model;

import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Almacenable<T> {
    void agregar(T item);
    
    T listar(int indice);
    
    void eliminar(int indice);
    
    void ordenar();
    
    void ordenar(Comparator<? super T> comparador);
    
    int tamanio();
    
    List<T> filtrar(Predicate<? super T> criterio);
    
    void paraCadaElemento(Consumer<? super T> action);
    
}
