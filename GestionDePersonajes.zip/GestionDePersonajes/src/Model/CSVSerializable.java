
package Model;

public interface CSVSerializable {
    public String toCSV();
 
    
}
