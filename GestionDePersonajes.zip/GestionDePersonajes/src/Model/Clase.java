
package Model;

public enum Clase {
    GUERRERO,MAGO,ARQUERO
}
