
package Model;

import static config.AppConstants.PATH_SERIAL;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T extends CSVSerializable & Comparable<T>> implements Almacenable<T>, Serializable{
    private List<T> items = new LinkedList<>();
    
    @Override
    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("No puedo almacenar algo nulo");
        }
        this.items.add(item);
    }
    
    @Override
    public T listar(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        validarIndice(indice);
        items.remove(indice);

        for (T item : items) {
            System.out.println(item);
        }
    }
    
    @Override
    public int tamanio() {
        return items.size();
    }
    
    @Override
    public void ordenar() {
        try {
            if (!items.isEmpty() && items.get(0) instanceof Comparable) {
                items.sort((Comparator<? super T>) Comparator.naturalOrder());
            }
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    @Override
    public void ordenar(Comparator<? super T> comparador) {
        items.sort(comparador);
    }
    
    private void validarIndice(int indice) {
        if (indice < 0 || indice >= tamanio()) {
            throw new IndexOutOfBoundsException("El elemento es menor a cero o es mayor al tamaño de la lista");
        }
    }
    
    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for (T item : items) {
            if (criterio.test(item)) {
                toReturn.add(item);
            }
        }
        return toReturn;
    }
    
    @Override
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T item : items) {
            accion.accept(item);
        }
    }
    
    
    public void guardarEnArchivo(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {

            salida.writeObject(items);

        } catch (IOException ex) {
            ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
    }


    public void cargarDesdeArchivo(String path) {

        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            items = (List<T>) entrada.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void guardarEnCSV(String path) {
        File archivo = new File(path);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
            bw.write("id,nombre,clase,nivel\n");
            for (CSVSerializable personaje : items) {
                if(personaje instanceof CSVSerializable){
                    bw.write(personaje.toCSV() + "\n");
                } else {
                    throw new IllegalArgumentException("No se puede guardar un objeto que no implementa CSVSerializable en un archivo CSV");
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());

        }
    }

    public Inventario<Personaje> cargarDesdeCSV(String path) {
        Inventario<Personaje> toReturn = new Inventario<>();

        File archivo = new File(path);

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            br.readLine();
            while ((linea = br.readLine()) != null) {
                if (linea.endsWith("\n")) {
                    linea = linea.substring(linea.length() - 1);
                }

                toReturn.agregar(Personaje.fromCSV(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }
}
